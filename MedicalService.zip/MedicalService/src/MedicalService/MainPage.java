package MedicalService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainPage extends JFrame {
    public MainPage() {
        setTitle("Welcome to Medical Service");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(70, 130, 180)); // Steel blue color
        JLabel titleLabel = new JLabel("Medical Service Portal");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);

        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(2, 1, 10, 10)); // Reduced vertical and horizontal gaps
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40)); // Reduced padding
        buttonPanel.setBackground(new Color(240, 248, 255)); // Alice blue background

        JButton signUpButton = new JButton("Sign Up");
        signUpButton.setFont(new Font("Arial", Font.PLAIN, 16)); // Smaller font size
        signUpButton.setBackground(new Color(0, 153, 76)); // Green button
        signUpButton.setForeground(Color.WHITE);
        signUpButton.setFocusPainted(false);
        signUpButton.setBorder(BorderFactory.createLineBorder(new Color(0, 102, 51), 2));
        signUpButton.setPreferredSize(new Dimension(50, 40)); // Reduced button size
        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SignUpPage();
                dispose();
            }
        });

        JButton signInButton = new JButton("Sign In");
        signInButton.setFont(new Font("Arial", Font.PLAIN, 16)); // Smaller font size
        signInButton.setBackground(new Color(0, 102, 204)); // Blue button
        signInButton.setForeground(Color.WHITE);
        signInButton.setFocusPainted(false);
        signInButton.setBorder(BorderFactory.createLineBorder(new Color(0, 51, 153), 2));
        signInButton.setPreferredSize(new Dimension(150, 40)); // Reduced button size
        signInButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SignInPage();
                dispose();
            }
        });

        buttonPanel.add(signUpButton);
        buttonPanel.add(signInButton);

        // Footer panel
        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(new Color(70, 130, 180)); // Steel blue color
        JLabel footerLabel = new JLabel("Your health, our priority");
        footerLabel.setFont(new Font("Arial", Font.ITALIC, 14));
        footerLabel.setForeground(Color.WHITE);
        footerPanel.add(footerLabel);

        // Add panels to frame
        add(headerPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(footerPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(null); // Center the window on the screen
        setVisible(true);
    }

    public static void main(String[] args) {
        new MainPage();
    }
}