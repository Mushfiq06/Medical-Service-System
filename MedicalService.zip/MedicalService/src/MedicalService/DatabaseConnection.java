package MedicalService;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    public static Connection getConnection() throws SQLException {
        try {
            String url = "jdbc:mysql://localhost:3306/MedicalServiceDB";
            String username = "root"; // Change this to your MySQL username
            String password = "utsha@123"; // Change this to your MySQL password
            return DriverManager.getConnection(url, username, password);
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new SQLException("Failed to connect to the database");
        }
    }
}
