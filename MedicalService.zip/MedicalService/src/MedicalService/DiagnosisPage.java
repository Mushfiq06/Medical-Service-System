package MedicalService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DiagnosisPage extends JFrame {
    private JComboBox<String>[] symptomDropdowns;

    public DiagnosisPage() {
        setTitle("Diagnosis Page");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(70, 130, 180));
        JLabel titleLabel = new JLabel("Select Symptoms", SwingConstants.CENTER);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerPanel.add(titleLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Symptoms Panel
        String[] symptoms = {
            "Do you have headache ?", "Do you have fever ?", "Do you have cough",
            "Do you have nausea ?", "Do you have nausea ?", "Do you have vomitting ?"
        };

        JPanel symptomPanel = new JPanel(new GridLayout(symptoms.length, 2, 15, 15));
        symptomPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        symptomDropdowns = new JComboBox[symptoms.length];

        for (int i = 0; i < symptoms.length; i++) {
            JLabel symptomLabel = new JLabel(symptoms[i]);
            symptomLabel.setFont(new Font("Arial", Font.PLAIN, 16));
            JComboBox<String> dropdown = new JComboBox<>(new String[]{"No", "Yes"});
            dropdown.setFont(new Font("Arial", Font.PLAIN, 14));
            symptomDropdowns[i] = dropdown;
            symptomPanel.add(symptomLabel);
            symptomPanel.add(dropdown);
        }

        add(symptomPanel, BorderLayout.CENTER);

        // Footer Panel with Buttons
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 10));
        JButton submitButton = new JButton("Submit");
        submitButton.setFont(new Font("Arial", Font.BOLD, 14));
        submitButton.setBackground(new Color(60, 179, 113));
        submitButton.setForeground(Color.WHITE);
        submitButton.setFocusPainted(false);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Arial", Font.BOLD, 14));
        logoutButton.setBackground(new Color(220, 20, 60));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFocusPainted(false);

        // Submit button action
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StringBuilder selectedSymptoms = new StringBuilder();
                for (int i = 0; i < symptomDropdowns.length; i++) {
                    if (symptomDropdowns[i].getSelectedItem().equals("Yes")) {
                        selectedSymptoms.append(i + 1).append(","); // Appending the symptom index
                    }
                }

                if (selectedSymptoms.length() > 0) {
                    selectedSymptoms.setLength(selectedSymptoms.length() - 1); // Remove last comma
                }

                new ResultPage(selectedSymptoms.toString());
                dispose();
            }
        });

        // Logout button action
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    dispose();
                }
            }
        });

        footerPanel.add(logoutButton);
        footerPanel.add(submitButton);
        add(footerPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new DiagnosisPage();
    }
}