// package MedicalService;

// import javax.swing.*;
// import javax.swing.table.DefaultTableModel;
// import java.awt.*;
// import java.sql.*;

// public class ResultPage extends JFrame {
//     public ResultPage(String symptoms) {
//         setTitle("Result Page");
//         setSize(600, 400);
//         setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

//         JTable resultTable = new JTable();
//         JScrollPane scrollPane = new JScrollPane(resultTable);
//         add(scrollPane, BorderLayout.CENTER);

//         String[] columnNames = {"Disease", "Recommended Test", "Recommended Medicines"};
//         DefaultTableModel model = new DefaultTableModel(columnNames, 0);
//         resultTable.setModel(model);

//         if (!symptoms.isEmpty()) {
//             try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/medicalservicedb", "root", "utsha@123")) {
//                 String sql = "SELECT disease_name, recommended_test, recommended_medicines FROM illnesses WHERE id IN (" + symptoms + ")";
//                 Statement stmt = conn.createStatement();
//                 ResultSet rs = stmt.executeQuery(sql);

//                 while (rs.next()) {
//                     String disease = rs.getString("disease_name");
//                     String test = rs.getString("recommended_test");
//                     String medicines = rs.getString("recommended_medicines");
//                     model.addRow(new Object[]{disease, test, medicines});
//                 }
//             } catch (SQLException ex) {
//                 JOptionPane.showMessageDialog(this, "Error fetching data from the database.");
//                 ex.printStackTrace();
//             }
//         }

//         JButton backButton = new JButton("Back");
//         backButton.addActionListener(e -> {
//             new DiagnosisPage();
//             dispose();
//         });
//         add(backButton, BorderLayout.SOUTH);

//         setLocationRelativeTo(null);
//         setVisible(true);
//     }
// }


package MedicalService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ResultPage extends JFrame {
    public ResultPage(String symptoms) {
        setTitle("Result Page");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(70, 130, 180));
        JLabel titleLabel = new JLabel("Diagnosis Results", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Table Section
        JTable resultTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(resultTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(scrollPane, BorderLayout.CENTER);

        String[] columnNames = {"Disease", "Recommended Test", "Recommended Medicines"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        resultTable.setModel(model);
        resultTable.setFont(new Font("Serif", Font.PLAIN, 14));
        resultTable.setRowHeight(25);
        resultTable.getTableHeader().setFont(new Font("Serif", Font.BOLD, 16));

        if (!symptoms.isEmpty()) {
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/medicalservicedb", "root", "utsha@123")) {
                String sql = "SELECT disease_name, recommended_test, recommended_medicines FROM illnesses WHERE id IN (" + symptoms + ")";
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);

                while (rs.next()) {
                    String disease = rs.getString("disease_name");
                    String test = rs.getString("recommended_test");
                    String medicines = rs.getString("recommended_medicines");
                    model.addRow(new Object[]{disease, test, medicines});
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error fetching data from the database.");
                ex.printStackTrace();
            }
        }

        // Button Panel 
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setBackground(new Color(220, 20, 60));
        backButton.setForeground(Color.WHITE);
        backButton.addActionListener(e -> {
            new DiagnosisPage();
            dispose();
        });
        buttonPanel.add(backButton);
        add(buttonPanel, BorderLayout.SOUTH);

        // Overall Styling
        getContentPane().setBackground(new Color(240, 248, 255));

        setLocationRelativeTo(null);
        setVisible(true);
    }
}