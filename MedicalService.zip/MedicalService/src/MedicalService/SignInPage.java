// package MedicalService;

// import javax.swing.*;
// import java.awt.*;
// import java.awt.event.ActionEvent;
// import java.awt.event.ActionListener;
// import java.sql.*;

// public class SignInPage extends JFrame {
//     public SignInPage() {
//         setTitle("Sign In");
//         setSize(500, 500);
//         setLayout(new GridBagLayout());
//         setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

//         GridBagConstraints gbc = new GridBagConstraints();
//         gbc.insets = new Insets(10, 10, 10, 10);

//         JLabel emailLabel = new JLabel("Email:");
//         JTextField emailField = new JTextField(20);
//         JLabel passwordLabel = new JLabel("Password:");
//         JPasswordField passwordField = new JPasswordField(20);
//         JButton submitButton = new JButton("Submit");
//         JButton backButton = new JButton("Back");

//         gbc.gridx = 0;
//         gbc.gridy = 0;
//         add(emailLabel, gbc);
//         gbc.gridx = 1;
//         add(emailField, gbc);

//         gbc.gridx = 0;
//         gbc.gridy = 1;
//         add(passwordLabel, gbc);
//         gbc.gridx = 1;
//         add(passwordField, gbc);

//         gbc.gridx = 0;
//         gbc.gridy = 2;
//         add(submitButton, gbc);
//         gbc.gridx = 1;
//         add(backButton, gbc);

//         submitButton.addActionListener(new ActionListener() {
//             @Override
//             public void actionPerformed(ActionEvent e) {
//                 try (Connection conn = DatabaseConnection.getConnection()) {
//                     String sql = "SELECT * FROM Users WHERE email = ? AND password = ?";
//                     PreparedStatement pst = conn.prepareStatement(sql);
//                     pst.setString(1, emailField.getText());
//                     pst.setString(2, new String(passwordField.getPassword()));
//                     ResultSet rs = pst.executeQuery();
//                     if (rs.next()) {
//                         new DiagnosisPage();
//                         dispose();
//                     } else {
//                         JOptionPane.showMessageDialog(null, "Invalid credentials");
//                     }
//                 } catch (SQLException ex) {
//                     ex.printStackTrace();
//                 }
//             }
//         });

//         backButton.addActionListener(new ActionListener() {
//             @Override
//             public void actionPerformed(ActionEvent e) {
//                 new MainPage();
//                 dispose();
//             }
//         });

//         setLocationRelativeTo(null);
//         setVisible(true);
//     }

//     public static void main(String[] args) {
//         new SignInPage();
//     }
// }








package MedicalService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class SignInPage extends JFrame {
    public SignInPage() {
        setTitle("Sign In");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Header Panel
        JPanel headerPanel = new JPanel();
        JLabel headerLabel = new JLabel("Welcome to Medical Service System");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 20));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.setBackground(new Color(70, 130, 180)); // Steel blue background
        headerPanel.add(headerLabel);

        // Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(new Color(240, 248, 255)); // Alice blue background
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        JTextField emailField = new JTextField(20);
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        JPasswordField passwordField = new JPasswordField(20);

        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(emailLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(emailField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(passwordLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(passwordField, gbc);

        // Button Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(240, 248, 255));
        JButton submitButton = new JButton("Submit");
        JButton backButton = new JButton("Back");

        submitButton.setFont(new Font("Arial", Font.BOLD, 14));
        submitButton.setBackground(new Color(60, 179, 113)); // Medium sea green
        submitButton.setForeground(Color.WHITE);

        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setBackground(new Color(220, 20, 60)); // Crimson
        backButton.setForeground(Color.WHITE);

        buttonPanel.add(submitButton);
        buttonPanel.add(backButton);

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try (Connection conn = DatabaseConnection.getConnection()) {
                    String sql = "SELECT * FROM Users WHERE email = ? AND password = ?";
                    PreparedStatement pst = conn.prepareStatement(sql);
                    pst.setString(1, emailField.getText());
                    pst.setString(2, new String(passwordField.getPassword()));
                    ResultSet rs = pst.executeQuery();
                    if (rs.next()) {
                        new DiagnosisPage();
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid credentials");
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new MainPage();
                dispose();
            }
        });

        // Add Panels to Frame
        add(headerPanel, BorderLayout.NORTH);
        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new SignInPage();
    }
}




